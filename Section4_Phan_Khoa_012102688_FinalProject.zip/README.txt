Work as group of 4:

My team:
012102688 (Phan, Khoa)
011908104 (Ly, Tien)


Other team:
011922131 (Le, Thong)

011967423 (Nguyen, Sang)




Whiteboard functions:

- The application allows user to add shape(s) to canvas

- The application allows user to edit a selected shape

- The application allows user to save/open the canvas work, and save canvas as PNG

- The application allows user to connect network (server - client)

- The application has a table for user to view data of shape(s)

- The application will start with 3 windows to test networking (1 server - 2 clients)

- The application won't allow user to open a canvas work while in server mode

- The application provides default host & port for networking

Whiteboard project:

- Source code has 3 parts:
	+ Main: main class of the project
	+ View: display to user
	+ Model: store data
- included Whiteboard.jar

