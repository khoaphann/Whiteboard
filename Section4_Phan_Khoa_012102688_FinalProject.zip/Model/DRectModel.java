package Model;

public class DRectModel extends DShapeModel {
    public DRectModel(){
        super();
    }
}
