package Model;

public class DOvalModel extends DShapeModel {
    public DOvalModel(){
        super();
    }
}
