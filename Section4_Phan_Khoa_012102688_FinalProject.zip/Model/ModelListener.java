package Model;

public interface ModelListener {
    void modelChanged(DShapeModel model);
}
